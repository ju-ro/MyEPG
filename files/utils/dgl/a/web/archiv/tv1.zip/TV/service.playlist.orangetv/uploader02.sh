#!/bin/bash

lftp -e 'cd Xb/; put /home/juraj/Dokumenty/.wg++/C:/Users/juraj.soviar/Documents/WG++/guide2.xml; bye' -u jurooo.wz.cz,Westeros123 ftp4.webzdarma.cz
