#! /bin/bash
source=$*
tempplaylist=$(mktemp -u)".m3u8"
stream=$(grep -A 1 "${source}$" /home/osmc/usr/records/orange/service.playlist.o2tv/orangetv.generic.m3u8 | head -n 2 | tail -n 1)
curl -qO ${tempplaylist} ${stream}
streamcount=$(cat ${tempplaylist} | grep -Eo "(http|https)://[\da-z./?A-Z0-9\D=_-]*" | wc -l)
streamcount=$((streamcount-1))
if  [ "$streamcount" = "-1" ]; then streamcount=0; fi
ffmpeg -protocol_whitelist file,http,https,tcp,tls -fflags +genpts -loglevel fatal -i ${tempplaylist} -probesize 32 -reconnect_at_eof 1 -reconnect_streamed 1 -c copy -map p:${streamcount}? -f mpegts -tune zerolatency -bsf:v h264_mp4toannexb,dump_extra -mpegts_service_type digital_tv pipe:1
