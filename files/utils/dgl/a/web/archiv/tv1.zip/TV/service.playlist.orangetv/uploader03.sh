#!/bin/bash

#lftp -e 'cd Xb/pi/; put /home/juraj/Documents/TV/zubo.orangetv/playlist/playlist1.m3u8; bye' -u jurooo.wz.cz,Westeros123 ftp4.webzdarma.cz

ncftpput -u jurooo.wz.cz -p Westeros123 ftp4.webzdarma.cz Xb/ /home/juraj/Documents/TV/zubo.orangetv/playlist/playlist1.m3u8
