<h1>365 EPG Generator</h1>

<p>

Python skript pro vygenerování XML souboru pro EPG

<p>

<a href="https://www.xbmc-kodi.cz/showthread.php?pid=84767#pid84767">Fórum</a>

<p>

<b><a href="https://www.paypal.me/petrsaros">DONATE</a></b>

<p>
