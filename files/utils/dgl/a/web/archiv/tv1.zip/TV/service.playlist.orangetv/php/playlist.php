﻿<?php
$channel = $_GET["ch"];
$url = ("http://jurooo.wz.cz/Xb/master_".$channel.".m3u8");
header('Location: '.$url.'');
exit;
?>

##EXTM3U
##EXTINF:-1 group-title="České televize",ČT 1
#http://webserver.cz/playlist.php?ch=357
##EXTINF:-1,ČT 2
#http://webserver.cz/playlist.php?ch=361
##EXTINF:-1,ČT 24
#http://webserver.cz/playlist.php?ch=447


#http://92.62.234.223/104/mystream.m3u8

#https://github.com/onigetoc/m3u8-PHP-Parser
#https://www.w3schools.com/php/php_syntax.aspv
#https://stackoverflow.com/questions/41820703/php-curl-parsing-a-m3u-file
