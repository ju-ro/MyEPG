#! /bin/bash
source=$*
playlist=/home/juraj/Dokumenty/service.playlist.orangetv/playlist/orangetv.generic.m3u8
playlistpath=$(dirname "${playlist}")"/"
stream=$(grep -A 1 "${source}$" $playlist | head -n 2 | tail -n 1)
tempplaylist=${playlistpath}${stream##*/}
if [ ! -f "${tempplaylist}" ]; then tempplaylist=$(mktemp -u)".m3u8";curl -L -f ${stream} -o ${tempplaylist}; fi
streamcount=$(cat ${tempplaylist} | grep -Eo "(http|https)://[\da-z./?A-Z0-9\D=_-]*" | wc -l)
streamcount=$((streamcount-1))
if  [ "$streamcount" = "-1" ]; then streamcount=0; fi
echo "source: ${source}" >&2
echo "stream: ${stream}" >&2
echo "tempplaylist: ${tempplaylist}" >&2
echo "streamcount: ${streamcount}" >&2
ffmpeg -protocol_whitelist file,http,https,tcp,tls -fflags +genpts -loglevel warning -i ${tempplaylist} -probesize 32 -reconnect_at_eof 1 -reconnect_streamed 1 -c copy -map p:${streamcount}? -f mpegts -tune zerolatency -bsf:v h264_mp4toannexb,dump_extra -mpegts_service_type digital_tv pipe:1
