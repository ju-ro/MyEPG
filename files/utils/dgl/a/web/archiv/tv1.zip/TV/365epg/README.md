<h2>365 EPG Generator</h2>

<p>

Python skript pro vygenerování XML souboru pro EPG (vyžaduje instalaci knihoven requests, bs4 a schedule)

<p>

<a href="https://www.xbmc-kodi.cz/showthread.php?pid=84767#pid84767">Fórum</a>

<p>

<b>DONATE</b>

<a href="https://www.paypal.me/petrsaros">PayPal</a>

<a href="https://revolut.me/petrsarka">Revolut</a> (@petrsarka)
<p>
