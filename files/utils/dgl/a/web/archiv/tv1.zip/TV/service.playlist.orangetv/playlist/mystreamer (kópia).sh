#! /bin/sh
source=$*
stream=$(grep -A 1 "${source}$" /home/juraj/Dokumenty/service.playlist.orangetv/playlist/ | head -n 2 | tail -n 1)
echo ${stream}
ffmpeg -fflags +genpts -loglevel info -re fatal -i ${stream} -map 0:50 -map 0:51 -vcodec copy -acodec copy -f mpegts -mpegts_service_type digital_tv pipe:1
