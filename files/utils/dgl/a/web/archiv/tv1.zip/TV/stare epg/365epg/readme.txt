Python skript na vygenerování EPG ve formátu XML podle zadaných parametrů.

treba nainštalovať sudo apt-get install python-bs4


1. parametr:
Počet dní od 1 do 15

2. paremetr:
Počet dní zpětně od 0 do 7

3. parametr:
Jaké kanály se mají generovat
    0 = všechny kanály
    1 = Cz/Sk kanály
    2 = vlastní kanály

Parametry se zadávají do souboru "settings.txt". Pokud soubor neexistuje, zadají se v terminálu.


Při zvolení parametru "Vlastní kanály" se vygenerují jen kanály uložené v souboru "channels.txt". Do tohoto souboru je potřeba zadat číselné id kanálů oddělené čárkou. Seznam id je v souboru "id.txt".
