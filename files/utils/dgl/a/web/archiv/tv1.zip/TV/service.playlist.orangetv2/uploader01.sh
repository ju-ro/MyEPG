#!/bin/bash

lftp -e 'cd Xb/; put /home/juraj/Dokumenty/service.playlist.orangetv/playlist/orangetv.playlist.m3u8; bye' -u jurooo.wz.cz,Westeros123 ftp4.webzdarma.cz
