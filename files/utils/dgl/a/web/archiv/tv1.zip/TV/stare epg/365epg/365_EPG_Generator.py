# -*- coding: utf-8 -*-

import sys
import os
import xmltv
import urllib2
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
from bs4 import BeautifulSoup
from urllib import urlencode
import unicodedata
import time


reload(sys)
sys.setdefaultencoding("utf8")
dn = os.path.dirname(os.path.realpath(__file__))
fn = os.path.join(dn,"guide.xml")
fs = os.path.join(dn,"settings.txt")
fch = os.path.join(dn,"channels.txt")


def sattv(d, d_b):
    headers = {"Accept-Language": "cs-CZ,en-US;q=0.9", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9","Referer":"https://www.satelitnatv.sk/tv-program/bbc-earth/", "Host": "www.satelitnatv.sk", "Content-type" : "application/x-www-form-urlencoded", "origin" : "https://www.satelitnatv.sk", "except-encoding" : "gzip, deflate"}
    programmes2 = []
    now = datetime.now()
    for i in range(d_b*-1, d):
        next_day = now + timedelta(days = i)
        date = next_day.strftime("%d.%m.%Y")
        data = urlencode({"datum" : date, "casOd" : "cely_den", "channel[]" : "BBC Earth", "channels_sub" : "Submit"})
        sys.stdout.write("\rBBC Earth: " + date)
        sys.stdout.flush()
        req = urllib2.Request("https://satelitnatv.sk/tv-program/bbc-earth/", data, headers)
        res = urllib2.urlopen(req, timeout = 5).read()
        soup = BeautifulSoup(res, "html.parser")
        items = soup.find_all("td",onclick=True)
        for x in items:
            name = x["onclick"].split("'")[1]
            desc = x["onclick"].split("'")[15]
            date = (x["onclick"].split("'")[13]).split(".")
            date = date[2] + date[1] + date[0]
            start_time = date + x["onclick"].split("'")[7].replace(":", "") + "00"
            stop_time = date + x["onclick"].split("'")[9].replace(":", "") + "00"
            programm = {"channel": "0-bbc-earth", "start": start_time  + " +0100", "stop": stop_time + " +0100", "title": [(name, "")], "desc": [(desc, "")]}
            if programm not in programmes2:
                programmes2.append(programm)
    for x in range(0, len(programmes2)):
        try:
            programmes2[x]["stop"]  = programmes2[x + 1]["start"]
        except: pass
    return programmes2


def encode(string):
    string = unicodedata.normalize("NFKD", string.decode("utf-8")).encode("ascii", "ignore")
    return string


def main():
    channels = []
    os.system("clear")
    if not os.path.exists(fs):
        days = int(raw_input("Počet dní (1 - 15): "))
        days_back = int(raw_input("Počet dní zpětně (0 - 7): "))
        channels_type = int(raw_input("Všechny/Cz-Sk/Vlastní kanály (0/1/2): "))
        os.system("clear")
    else:
        settings = open(fs).read().splitlines()
        days = int(settings[0])
        days_back = int(settings[1])
        channels_type = int(settings[2])
    ch = {}
    cchc = ""
    programmes = []
    html = urllib2.urlopen("http://programandroid.365dni.cz/android/v5-tv.php?locale=cs_CZ", timeout = 5).read()
    root = ET.fromstring(html)
    if channels_type == 0:
        bbc = True
        channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth','icon': [{'src': 'https://www.satelitnatv.sk//obrazky/loga_stanic/50/bbc_earth_50.png'}]})
        for i in root.iter("a"):
            ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower())
            channels.append({"display-name": [(i.find("n").text, u"cs")], "id": encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower()), "icon": [{"src": "http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/" + str(i.find("o").text)}]})
    elif channels_type == 1:
        bbc = True
        channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth','icon': [{'src': 'https://www.satelitnatv.sk//obrazky/loga_stanic/50/bbc_earth_50.png'}]})
        for i in root.iter("a"):
            if i.find("p").text == "České" or i.find("p").text == "Slovenské":
                ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower())
                channels.append({"display-name": [(i.find("n").text, u"cs")], "id": encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower()), "icon": [{"src": "http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/" + str(i.find("o").text)}]})
    elif channels_type == 2:
        cchc = open(fch).read()
        cch = cchc.split(",")
        if "0" in cch:
            cch.remove("0")
            bbc = True
            channels.append({'display-name': [('BBC Earth', u'cs')], 'id': '0-bbc-earth','icon': [{'src': 'https://www.satelitnatv.sk//obrazky/loga_stanic/50/bbc_earth_50.png'}]})
        else:
            bbc = False
        if cchc != "0":
            for i in root.iter("a"):
                if i.attrib["id"] in cch:
                    ch[i.attrib["id"]] = encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower())
                    channels.append({"display-name": [(i.find("n").text, u"cs")], "id": encode((i.attrib["id"] + "-" + i.find("n").text).replace(" ", "-").lower()), "icon": [{"src": "http://portal2.sms.cz/kategorie/televize/bmp/loga/velka/" + str(i.find("o").text)}]})
    chl = ",".join(ch.keys())
    print("Generuje se " + str(len(channels)) + " kanálů")
    if bbc == True:
        programmes2 = sattv(days, days_back)
        for y in programmes2:
            programmes.append(y)
    now = datetime.now()
    for i in range(days_back*-1, days):
        next_day = now + timedelta(days = i)
        date = next_day.strftime("%Y-%m-%d")
        date_ = next_day.strftime("%d.%m.%Y")
        if channels_type == 0:
            cht = "Všechny kanály: "
        elif channels_type == 1:
            cht = "Cz/Sk kanály: "
        else:
            cht = "Vlastní kanály: "
        sys.stdout.write("\r" + cht + date_)
        sys.stdout.flush()
        if cchc != "0":
            try:
                html = urllib2.urlopen("http://programandroid.365dni.cz/android/v5-program.php?datum=" + date + "&id_tv=" + chl, timeout = 5).read()
            except urllib2.URLError, e:
                os.system("clear")
                print("Chyba: " + str(e))
                return
            root = ET.fromstring(html)
            root[:] = sorted(root, key=lambda child: (child.tag,child.get("o")))
            for i in root.iter("p"):
                n = i.find("n").text
                try:
                    k = i.find("k").text
                except:
                    k = ""
                if ch.has_key(i.attrib["id_tv"]):
                    programmes.append({"channel": ch[i.attrib["id_tv"]].replace("804-ct-art", "805-ct-:d"), "start": i.attrib["o"].replace("-", "").replace(":", "").replace(" ", "") + " +0100", "stop": i.attrib["d"].replace("-", "").replace(":", "").replace(" ", "") + " +0100", "title": [(n, "")], "desc": [(k, "")]})
    w = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")
    os.system("clear")
    print("Ukládá se...")
    for c in channels:
        w.addChannel(c)
    for p in programmes:
        w.addProgramme(p)
    w.write(fn, pretty_print=True)
    os.system("clear")
    print("Hotovo")


if __name__ == "__main__":
    main()
