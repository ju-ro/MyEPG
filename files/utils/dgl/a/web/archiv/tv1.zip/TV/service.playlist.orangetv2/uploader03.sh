#!/bin/bash

lftp -e 'cd Xb/; put /home/juraj/Dokumenty/zubo.orangetv/playlist/playlist.m3u8; bye' -u jurooo.wz.cz,Westeros123 ftp4.webzdarma.cz
