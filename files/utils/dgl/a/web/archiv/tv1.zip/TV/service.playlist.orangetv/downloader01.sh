#!/bin/bash

HOST=ftp4.webzdarma.cz  #This is the FTP servers host or IP address.
USER=jurooo.wz.cz             #This is the FTP user that has access to the server.
PASS=Westeros123         #This is the password for the FTP user.


ftp -inv $HOST << EOF


user $USER $PASS

cd Xb/

lcd /home/juraj/Dokumenty/.wg++/

get WebGrab++.config.xml

bye

EOF
