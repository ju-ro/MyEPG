#!/bin/bash


rm /home/juraj/Documents/TV/365epg/generator.py 
ncftpget -R -u jurooo.wz.cz -p Westeros123 ftp4.webzdarma.cz /home/juraj/Documents/TV/365epg epg/generator.py 