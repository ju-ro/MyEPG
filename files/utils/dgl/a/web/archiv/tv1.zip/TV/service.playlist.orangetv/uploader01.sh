#!/bin/bash

#lftp -c 'cd /epg/; put /home/juraj/Documents/TV/service.playlist.orangetv/playlist/orangetv.playlist1.m3u8; bye' -u jurooo.wz.cz,Westeros123 ftp4.webzdarma.cz

ncftpput -u jurooo.wz.cz -p Westeros123 ftp4.webzdarma.cz Xb/ /home/juraj/Documents/TV/service.playlist.orangetv/playlist/orangetv.playlist1.m3u8


