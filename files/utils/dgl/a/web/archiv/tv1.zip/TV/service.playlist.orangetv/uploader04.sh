#!/bin/bash

lftp -e 'cd Xb/; put /home/juraj/Dokumenty/365epg3/guide.xml; bye' -u jurooo.wz.cz,Westeros123 ftp4.webzdarma.cz
