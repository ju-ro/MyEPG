﻿<?php
$channel = $_GET["ch"];
$url = ("http://xxx.xxx.xxx.xxx/master_".$channel.".m3u8");
header('Location: '.$url.'');
exit;
?>

---------------------
výsledok:
---------------------

#EXTM3U
#EXTINF:-1 group-title="České televize",ČT 1
http://webserver.cz/playlist.php?ch=357
#EXTINF:-1,ČT 2
http://webserver.cz/playlist.php?ch=361
#EXTINF:-1,ČT 24
http://webserver.cz/playlist.php?ch=447
